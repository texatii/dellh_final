# Genealogy & AVL Tree Project

Ένα project σε Java που περιλαμβάνει:
1. **Genealogy:** Υπολογισμός συγγενικών σχέσεων από αρχείο CSV.
2. **AVL Tree:** Υλοποίηση Self-balancing BST με υποστήριξη duplicates.

##  Δομή Αρχείων
* `Genealogy.java`: Κύρια λογική γενεαλογίας & CSV parser.
* `AVLTree.java`: Υλοποίηση AVL δέντρου.
* `TestRunner.java`: Unit tests.
* `persons.csv`: Αρχείο δεδομένων (Απαραίτητο).

##  Compilation
Ανοίξτε τερματικό στον φάκελο των αρχείων και τρέξτε:

```bash
javac -d . *.java