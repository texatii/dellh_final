Ιωάννης Δερμιτζάκης - ΑΜ (2879163) E εώς F

Γεώργιος Κατρακούλης - ΑΜ (2879172) C εώς D

Θεόδωρος Μαυρακάκης - ΑΜ (2879178) Α εώς Β



 Ανοίξτε τερματικό στον φάκελο με τα .java αρχεία και τρέξτε:
javac -d . *.java

### EXECUTION
# 1. Genealogy (Απαιτείται το αρχείο persons.csv στον ίδιο φάκελο)
java com.mycompany.testrunner.Genealogy "Ιωάννης Καποδίστριας" "Αυγουστίνος Καποδίστριας"

# 2. AVL Tree
java com.mycompany.testrunner.AVLTree

# 3. Unit Tests
java com.mycompany.testrunner.TestRunner